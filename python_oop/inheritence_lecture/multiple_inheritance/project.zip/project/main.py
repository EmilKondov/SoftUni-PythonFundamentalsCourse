from project.teacher import Teacher

teacher = Teacher()

print(teacher.sleep())
print(teacher.get_fired())
print(teacher.teach())