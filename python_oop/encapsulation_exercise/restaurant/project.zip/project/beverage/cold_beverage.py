from project.beverage.beverage import Beverage


class ColdBeverage(Beverage):
    pass


"""
Тук казваме, съществува  такъв клас (ColdBeverage), който наследява клас (Beverage). 
Тъй като нямаме логика тук и нищо друго не се извършва пишем pass и го оставяме така.
Същото се отнася и за HotBeverage.
"""